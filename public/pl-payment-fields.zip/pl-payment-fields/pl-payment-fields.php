<?php
/**
 * Plugin Name: Premium Lenses Payment Fields
 * Description: Adds Juice number, bank account, and WhatsApp fields to the Global Settings ACF group. Safe to keep active.
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) exit;

add_action('acf/init', 'pl_register_payment_fields');

function pl_register_payment_fields() {
    if (!function_exists('acf_add_local_field_group')) return;

    acf_add_local_field_group([
        'key'      => 'group_pl_payment',
        'title'    => 'Payment & Contact Details',
        'fields'   => [
            [
                'key'           => 'field_juice_number',
                'label'         => 'Juice Number',
                'name'          => 'juice_number',
                'type'          => 'text',
                'instructions'  => 'MCB Juice mobile payment phone number (e.g. 52 123 456)',
                'placeholder'   => '52 123 456',
            ],
            [
                'key'           => 'field_bank_name',
                'label'         => 'Bank Name',
                'name'          => 'bank_name',
                'type'          => 'text',
                'instructions'  => 'e.g. MCB, Bank One',
                'placeholder'   => 'MCB',
            ],
            [
                'key'           => 'field_account_holder_name',
                'label'         => 'Account Holder Name',
                'name'          => 'account_holder_name',
                'type'          => 'text',
                'placeholder'   => 'Premium Lenses Ltd',
            ],
            [
                'key'           => 'field_bank_account_number',
                'label'         => 'Bank Account Number',
                'name'          => 'bank_account_number',
                'type'          => 'text',
                'placeholder'   => '000123456789',
            ],
            [
                'key'           => 'field_whatsapp_number',
                'label'         => 'WhatsApp Number',
                'name'          => 'whatsapp_number',
                'type'          => 'text',
                'instructions'  => 'International format without + (e.g. 23052123456)',
                'placeholder'   => '23052123456',
            ],
        ],
        'location' => [
            [
                [
                    'param'    => 'page',
                    'operator' => '==',
                    'value'    => '38',
                ],
            ],
        ],
        'show_in_rest' => true,
    ]);
}
